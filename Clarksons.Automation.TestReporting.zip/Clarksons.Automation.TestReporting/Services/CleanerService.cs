﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clarksons.Automation.TestReporting.Services
{
    public class CleanerService
    {
        private static List<string> _garbage;
        public static CleanerService Instance { get; private set; }

        private CleanerService()
        {
            _garbage = new List<string>();
        }

        public static void Init()
        {
            Instance = new CleanerService();
        }

        public static void AddFile(string garbage)
        {
            _garbage.Add(garbage);
        }

        public static void ClearGargage()
        {
            _garbage.ForEach(file => File.Delete(file));
        }
    }
}
