﻿namespace Clarksons.Automation.TestReporting.Services
{
    public interface ITestTransformer
    {
        void ToJsonFormat(string filePath);
    }
}
