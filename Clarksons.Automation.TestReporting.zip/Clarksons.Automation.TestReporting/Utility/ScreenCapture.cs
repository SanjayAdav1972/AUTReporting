﻿using Clarksons.Automation.TestReporting.Services;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clarksons.Automation.TestReporting.Utility
{
    public class ScreenCapture : IObservable<string>
    {
        private BrowserSession _browsersession;

        private List<IObserver<string>> _observers;

        public static ScreenCapture Instance { get; private set; }

        private ScreenCapture(BrowserSession browserSession)
        {
            _browsersession = browserSession;
            _observers = new List<IObserver<string>>();
        }

        private void SaveJpeg(string path, Image img, int quality)
        {
            if (quality < 0 || quality > 100)
                throw new ArgumentOutOfRangeException("quality must be between 0 and 100.");

            // Encoder parameter for image quality 
            EncoderParameter qualityParam = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, quality);
            // JPEG image codec 
            ImageCodecInfo jpegCodec = GetEncoderInfo("image/jpeg");
            EncoderParameters encoderParams = new EncoderParameters(1);
            encoderParams.Param[0] = qualityParam;
            img.Save(path, jpegCodec, encoderParams);
        }

        /// <summary> 
        /// Returns the image codec with the given mime type 
        /// </summary> 
        private static ImageCodecInfo GetEncoderInfo(string mimeType)
        {
            // Get image codecs for all image formats 
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();

            // Find the correct image codec 
            for (int i = 0; i < codecs.Length; i++)
                if (codecs[i].MimeType == mimeType)
                    return codecs[i];

            return null;
        }

        public static void Init(BrowserSession browserSession)
        {
            Instance = new ScreenCapture(browserSession);

            if (CleanerService.Instance == null)
                CleanerService.Init();
        }

        public IDisposable Subscribe(IObserver<string> observer)
        {
            if (!_observers.Contains(observer))
                _observers.Add(observer);
            return new Unsubscriber(_observers, observer);
        }

        /// <summary>
        /// Take a screenshot of the current page, then notify the Observer linked to it (if any) with the storage path.
        /// </summary>
        public string TakeScreenshot(string filename)
        {
            
            string storagePath = ConfigurationManager.AppSettings["ScreenshotStoreLocation"];
            string artifactPath = ConfigurationManager.AppSettings["ScreenshotArtifactLocation"];

            if (!System.IO.Directory.Exists(storagePath))
                System.IO.Directory.CreateDirectory(storagePath);

            //Do some operations on the just capture picture before saving it
            string final = System.IO.Path.Combine(storagePath, filename.RemoveWhitespace());
            string temp = System.IO.Path.Combine(storagePath, $"temp{Tools.GenerateRandomInt()}.jpg");
            _browsersession.SaveScreenshot(temp, ImageFormat.Jpeg);

            Image img = Image.FromFile(temp, true);
            SaveJpeg(final, img, 40);
            CleanerService.AddFile(temp);
            img.Dispose();

            string screenPath = System.IO.Path.Combine(artifactPath, filename.RemoveWhitespace());

            _observers.ForEach(obs => obs.OnNext(screenPath));

            return screenPath;
        }

        private class Unsubscriber : IDisposable
        {
            private List<IObserver<string>> _observers;
            private IObserver<string> _observer;

            public Unsubscriber(List<IObserver<string>> observers, IObserver<string> observer)
            {
                this._observers = observers;
                this._observer = observer;
            }

            public void Dispose()
            {
                if (_observer != null && _observers.Contains(_observer))
                    _observers.Remove(_observer);
            }
        }
    }


}
