﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.Automation.TestReporting.Utility
{
    public static class Extensions
    {
        public static string SplitList(this List<string> list, bool carriagereturn = false)
        {
            string strList = string.Empty;
            string separator = string.Empty;
            if (carriagereturn)
                separator = "\n";
            else
                separator = " ";
            foreach (var str in list)
            {
                strList += str + separator;
            }

            return strList.Trim();
        }

        public static string RemoveWhitespace(this string input)
        {
            return new string(input.ToCharArray().Where(c => !Char.IsWhiteSpace(c)).ToArray());
        }
    }
}
