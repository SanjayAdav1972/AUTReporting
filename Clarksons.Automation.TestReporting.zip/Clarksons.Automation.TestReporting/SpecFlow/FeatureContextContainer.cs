﻿using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace Clarksons.Automation.TestReporting.SpecFlow
{
    public class FeatureContextContainer
    {
        public int Id { get; }
        public int Total { get; set; }
        public int Passed { get; set; }
        public int Failed { get; set; }
        public int Inconclusive { get; set; }

        public string Title { get; }
        public List<ScenarioContextContainer> ScenarioList { get; set; }

        private ScenarioContextContainer _lastAdded;

        public FeatureContextContainer(FeatureContext context)
        {
            Title = context.FeatureInfo.Title;
            ScenarioList = new List<ScenarioContextContainer>();
            Id = Utility.Tools.GenerateRandomInt();
        }

        /// <summary>
        /// Add a scenario to the Feature Context.
        /// </summary>
        /// <param name="scenario">ScenarioContext from SpecFlow</param>
        public void AddScenario(ScenarioContext scenario)
        {
            _lastAdded = new ScenarioContextContainer(scenario);
            ScenarioList.Add(_lastAdded);
        }

        public ScenarioContextContainer GetLastAddedScenario() => _lastAdded;

        public void UpdateScenarioCount()
        {
            Total += 1;

            switch(GetLastAddedScenario().Status)
            {
                case Enums.TestStatus.Failed:
                    Failed += 1;
                    break;
                case Enums.TestStatus.Passed:
                    Passed += 1;
                    break;
                case Enums.TestStatus.Inconclusive:
                    Inconclusive += 1;
                    break;
            }
        }
    }
}
