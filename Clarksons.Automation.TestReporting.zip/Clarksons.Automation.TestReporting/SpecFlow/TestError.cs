﻿namespace Clarksons.Automation.TestReporting.SpecFlow
{
    /// <summary>
    /// Container for test output information
    /// </summary>
    public class TestOutput
    {
        public string StackTrace { get; set; }
        public string Message { get; set; }

        public TestOutput()
        {
            StackTrace = string.Empty;
            Message = string.Empty;
        }
    }
}
