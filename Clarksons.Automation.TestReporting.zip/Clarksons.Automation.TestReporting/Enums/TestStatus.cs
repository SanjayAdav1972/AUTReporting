﻿namespace Clarksons.Automation.TestReporting.Enums
{
    public enum TestStatus
    {
        NotRun,
        Passed,
        Failed,
        Inconclusive
    }
}
